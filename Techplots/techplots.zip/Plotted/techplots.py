import pandas as pd
import matplotlib.pyplot as plt

# Specify the path to your CSV file
file_path = r'C:\Users\racha\Downloads\BL_Kit\pmostechplots\gmro.csv'

# Load the CSV data into a DataFrame
df = pd.read_csv(file_path)

# Wavelengths you mentioned: 120nm, 1020nm, 1120nm, 220nm, 320nm, 420nm, 520nm, 620nm, 720nm, 820nm, 920nm
wavelengths = [120, 1020, 1120, 220, 320, 420, 520, 620, 720, 820, 920]

# Set up the plot
plt.figure(figsize=(10, 6))

# Loop through the wavelengths and plot the data for each pair of columns
for i, wavelength in enumerate(wavelengths):
    # Extract columns based on pairs (e.g., col1 and col2 for 120nm)
    x_column = df.iloc[:, 2*i]   # 1st column of the pair
    y_column = df.iloc[:, 2*i+1] # 2nd column of the pair
    
    # Plot each pair with a label indicating the wavelength
    plt.plot(x_column, y_column, label=f'L = {wavelength}nm')

# Add labels and title
plt.title('gm*ro vs gm/Id (PMOS)')
plt.xlabel('gm/Id')
plt.ylabel('gm*ro')

# Display the legend to identify the wavelengths
plt.legend()

# Show the plot
plt.show()
